package model.collectibles;

import java.util.ArrayList;

import engine.Game;
import exceptions.NoAvailableResourcesException;
import model.characters.Hero;

public class Vaccine implements Collectible {

	public Vaccine() {
		
	}

	public void pickUp(Hero h) {
		ArrayList<Vaccine> A=h.getVaccineInventory();
		
		A.add(this);
		
	}

	@Override
	public void use(Hero h) throws NoAvailableResourcesException {
		ArrayList<Vaccine> A =h.getVaccineInventory();
		if(A.isEmpty())
			throw new NoAvailableResourcesException("No available vaccines");
		A.remove(this);	
		Game.zombies.remove(h.getTarget());
		
	}

}
