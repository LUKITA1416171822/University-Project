package model.collectibles;

import java.util.ArrayList;

import exceptions.*;
import model.characters.Hero;

public class Supply implements Collectible  {

	public Supply() {
		
	}

	public void pickUp(Hero h) {
		
		ArrayList<Supply> A=h.getSupplyInventory();
		A.add(this);
		
	}

	@Override
	public void use(Hero h) throws NoAvailableResourcesException {
		ArrayList<Supply> A =h.getSupplyInventory();
		if(A.isEmpty())
			throw new NoAvailableResourcesException("No available supplies");
		A.remove(this);
		
	}


	
		
		

}
