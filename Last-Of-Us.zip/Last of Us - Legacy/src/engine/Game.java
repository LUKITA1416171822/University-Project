package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import exceptions.InvalidTargetException;
import exceptions.NotEnoughActionsException;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.Cell;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public class Game {
	
	public static Cell [][] map =new CharacterCell[15][15];
	public static ArrayList <Hero> availableHeroes = new ArrayList<Hero>();
	public static ArrayList <Hero> heroes =  new ArrayList<Hero>();
	public static ArrayList <Zombie> zombies =  new ArrayList<Zombie>();
	
	
	
		
	public static void loadHeroes(String filePath)  throws IOException {
		
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Hero hero=null;
			switch (content[1]) {
			case "FIGH":
				hero = new Fighter(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3]));
				break;
			case "MED":  
				hero = new Medic(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3])) ;
				break;
			case "EXP":  
				hero = new Explorer(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3]));
				break;
			}
			availableHeroes.add(hero);
			line = br.readLine();
			
			
		}
		br.close();

		
		
	}
	
	
	public static void startGame(Hero h) {
		availableHeroes.remove(h);
		heroes.add(h);
		CharacterCell c1=(CharacterCell)map[0][0];
		c1.setCharacter(h);
		Point t=new Point(0,0);
		Hero.SetAdjacentVisibility(t);
		map[0][0].setVisible(true);
	    h.setLocation(t);	
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while((l==0 && s==0)|| (map[l][s] instanceof CollectibleCell)||(map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new CollectibleCell(new Supply());
			 
			 
		}
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while((l==0 && s==0)|| (map[l][s] instanceof CollectibleCell)||(map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new CollectibleCell(new Vaccine());
			 
			 
		}
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while((l==0 && s==0)|| (map[l][s] instanceof CollectibleCell)||(map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new TrapCell();
			 
			 
		}
		for(int i=0;i<10;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while((l==0 && s==0)|| (map[l][s] instanceof CollectibleCell)||(map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			do {
				if (map[l][s] instanceof  CharacterCell) {
					CharacterCell x=(CharacterCell) map[l][s];
					if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)) {
						l= (int) (Math.random()*15);
						  s= (int) (Math.random()*15);
					}
					else {
						break;
					}
				}
			 }while(true);
			CharacterCell c=(CharacterCell)map[l][s];
			Zombie z=new Zombie();
			c.setCharacter(z);
			z.setLocation(new Point(l,s));
			zombies.add(z);
			 
			 
		}}
	public static boolean checkWin() {
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					CollectibleCell cc=(CollectibleCell) map[i][j];
					if(cc.getCollectible() instanceof Vaccine)
						return false;
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
			Hero hh=heroes.get(i);
			if(!(hh.getVaccineInventory().isEmpty()))
				return false;
		}
		if(heroes.size()>=5)
			return true;
		else {
			return false;
		}
	}
	
	
	public static boolean checkGameOver() {
		if(heroes.isEmpty())
			return true;
		
		
		int x=heroes.size()+availableHeroes.size();
		
//		if(x<5) {
//			return true;
//		}
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					CollectibleCell cc=(CollectibleCell) map[i][j];
					if(cc.getCollectible() instanceof Vaccine)
						return false;
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
			Hero hh=heroes.get(i);
			if(!(hh.getVaccineInventory().isEmpty()))
				return false;
		}
		return true;
		
	}
	public static void endTurn() throws InvalidTargetException, NotEnoughActionsException {
		//to do #1 neloop 3ala el xzombies to attack adjacent cells ✅
		//to do #2 neloop 3ala el heroes ne5ally:
//		actions available, 
//		target==null,
//		specialaction ne5alleeh befalse ,
//		set adjacent visibility of el heroes,
//		and a random zombie 
		
		for(int i=0;i<zombies.size();i++) {
			Zombie z=zombies.get(i);
			
			int X=z.getLocation().x;
			int Y=z.getLocation().y;
			Point Right=new Point(X+1,Y);
			if(Right.x>=0&&Right.x<15) {
				if(Game.map[Right.x][Right.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[Right.x][Right.y];
				if(ccc.getCharacter() instanceof Hero) {
					z.setTarget(ccc.getCharacter());
					z.attack();
					continue;
				}}
						}
			Point Left=new Point(X-1,Y);
			if(Left.x>=0&&Left.x<15) {
				if(Game.map[Left.x][Left.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[Left.x][Left.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				
				
				}
			Point Top=new Point(X,Y+1);
			if(Top.y>=0&&Top.y<15)
				if(Game.map[Top.x][Top.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[Top.x][Top.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				
				
				
				
				
			Point Bottom =new Point(X,Y-1);
			if(Bottom.y>=0&&Bottom.y<15)
				if(Top.y>=0&&Top.y<15)
					if(Game.map[Bottom.x][Bottom.y] instanceof CharacterCell) {
						CharacterCell ccc= (CharacterCell)Game.map[Bottom.x][Bottom.y];
						if(ccc.getCharacter() instanceof Hero) {
							z.setTarget(ccc.getCharacter());
							z.attack();
							continue;
						}
						
						}
				
				
				
				
			Point TopRight=new Point(X+1,Y+1);
			if(TopRight.y>=0&&TopRight.y<15&&TopRight.x>=0&&TopRight.x<15)
				if(Game.map[TopRight.x][TopRight.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[TopRight.x][TopRight.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				
				
				
			Point TopLeft=new Point(X-1,Y+1);
			if(TopLeft.y>=0&&TopLeft.y<15&&TopLeft.x>=0&&TopLeft.x<15)
				if(Game.map[TopLeft.x][TopLeft.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[TopLeft.x][TopLeft.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				
				
				
			Point BottomRight=new Point(X+1,Y-1);
			if(BottomRight.y>=0&&BottomRight.y<15 && BottomRight.x>=0&& BottomRight.x<15)
				if(Game.map[BottomRight.x][BottomRight.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[BottomRight.x][BottomRight.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				
				
				
			Point BottomLeft=new Point(X-1,Y-1);
			if(BottomLeft.y>=0&&BottomLeft.y<15&&BottomLeft.x>=0&&BottomLeft.x<15)
				if(Game.map[BottomLeft.x][BottomLeft.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[BottomLeft.x][BottomLeft.y];
					if(ccc.getCharacter() instanceof Hero) {
						z.setTarget(ccc.getCharacter());
						z.attack();
						continue;
					}
					
					}
				}
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					map[i][j].setVisible(false);
					
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
        Hero h=heroes.get(i);
        h.setActionsAvailable(h.getMaxActions());
        h.setTarget(null);
        h.setSpecialAction(false);
      
        Hero.SetAdjacentVisibility(h.getLocation());
        
        }
		
		
		int l= (int) (Math.random()*15);
		 int s= (int) (Math.random()*15);
		
		 while((l==0 && s==0)|| (Game.map[l][s] instanceof CollectibleCell)||(Game.map[l][s] instanceof TrapCell)) {
			  l= (int) (Math.random()*15);
			  s= (int) (Math.random()*15);
		 }
		do {
			if (Game.map[l][s] instanceof  CharacterCell) {
				CharacterCell x=(CharacterCell) Game.map[l][s];
				if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)){
					l= (int) (Math.random()*15);
					  s= (int) (Math.random()*15);
				}
				else {
					break;
				}
			}
		 }while(true);
		CharacterCell D=(CharacterCell)Game.map[l][s];
		Zombie z=new Zombie();
		D.setCharacter(z);
		Game.zombies.add(z);
		z.setLocation(new Point(l,s));
		
		for(int i=0;i<zombies.size();i++) {
			zombies.get(i).setTarget(null);
		}
		
		
	}
	
	



}