package model.characters;

import java.awt.Point;

import engine.Game;
import exceptions.*;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;


public abstract class Character {
	private String name;
	private Point location;
	private int maxHp;
	private int currentHp;
	private int attackDmg;
	private Character target;

	
	public Character() {
	}
	

	public Character(String name, int maxHp, int attackDmg) {
		this.name=name;
		this.maxHp = maxHp;
		this.currentHp = maxHp;
		this.attackDmg = attackDmg;
	}
		
	public Character getTarget() {
		return target;
	}

	public void setTarget(Character target) {
		this.target = target;
	}
	
	public String getName() {
		return name;
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public int getMaxHp() {
		return maxHp;
	}

	public int getCurrentHp() {
		return currentHp;
	}

	public void setCurrentHp(int currentHp) {
		if(currentHp <= 0) {
			 
			this.currentHp = 0;
			this.onCharacterDeath();}
		else if(currentHp > maxHp) 
			this.currentHp = maxHp;
		else 
			this.currentHp = currentHp;
	}

	public int getAttackDmg() {
		return attackDmg;
	}
	abstract public void attack() throws InvalidTargetException,NotEnoughActionsException ;
//		if(this.getTarget()==null)
//			throw new InvalidTargetException();
//			if(this instanceof Hero && this.getTarget() instanceof Hero)
//				throw new InvalidTargetException();
//			if(this instanceof Zombie && this.getTarget() instanceof Zombie)
//				throw new InvalidTargetException();
//			if(Math.abs(getTarget().getLocation().x-this.getLocation().x)>1 || Math.abs(getTarget().getLocation().y-this.getLocation().y)>1) 
//				throw new InvalidTargetException("Can't attack non-adjacent cells.");
//			if(this instanceof Hero) {
//				
//				Hero H =(Hero)this;
//				if(!(H instanceof Fighter && H.isSpecialAction())) {
//				int x=H.getActionsAvailable();
//				if(x>0) {
//					x-=1;
//					H.setActionsAvailable(x);
//				}
//				else {
//					throw new NotEnoughActionsException();
//				}}
//			}
//		
//		
//		
//			int cHp=getTarget().getCurrentHp();
//			cHp-=this.getAttackDmg();
//			getTarget().setCurrentHp(cHp);
//			
//			
//				
//			getTarget().defend(this);
//			
		
			
		
	
	abstract public void defend(Character c) ;
		
	
	
	
	
	
	
	
	
	
	
	public void onCharacterDeath() {
		CharacterCell c=(CharacterCell)(Game.map[this.getLocation().x][this.getLocation().y]);
		c.setVisible(true);
		c.setCharacter(null);
	
		if(this instanceof Hero) {
		Game.heroes.remove(this);
//		for(int i=0;i<Game.zombies.size();i++)
//		{
//			Zombie z=Game.zombies.get(i);
//			if((Hero)z.getTarget()==this)
//				z.setTarget(null);
//		}

		}
		
		else {
			
			Game.zombies.remove(this);
			
			
			int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while((l==0 && s==0)|| (Game.map[l][s] instanceof CollectibleCell)||(Game.map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			do {
				if (Game.map[l][s] instanceof  CharacterCell) {
					CharacterCell x=(CharacterCell) Game.map[l][s];
					if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)) {
						l= (int) (Math.random()*15);
						  s= (int) (Math.random()*15);
					}
					else {
						break;
					}
				}
			 }while(true);
			CharacterCell D=(CharacterCell)Game.map[l][s];
			Zombie z=new Zombie();
			D.setCharacter(z);
			Game.zombies.add(z);
			z.setLocation(new Point(l,s));
//			for(int i=0;i<Game.heroes.size();i++)
//			{
//				Hero zz=Game.heroes.get(i);
//				if((Zombie)zz.getTarget()==this)
//					zz.setTarget(null);
//			}
		}
		
		
	}
	

}